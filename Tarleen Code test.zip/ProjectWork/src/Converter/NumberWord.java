package Converter;

import java.util.HashMap;

public class NumberWord {
	private static String[] ones=new String[]
			{
					"",
					" One",
					" Two", 
					" Three",
					" Four",
					" Five",
					" Six",
					" Seven",
					" Eight",
					" Nine",
					" Ten",
					" Eleven",
					" Twelve",
					" Thirteen",
					" Fourteen",
					" Fifteen",
					" Sixteen",
					" Seventeen",
					" Eighteen",
					" Ninteen"
			};
	private static String[] tens=new String[]
			{
					"",
					" Ten",
					" Twenty",
					" Thirty", 
					" Forty",
					" Fifty",
					" Sixty",
					" Seventy",
					" Eighty",
					" Nighty"
			};
	

	public static String numberConverter(long number) throws Exception
	{
		String word=String.valueOf(number);
		String finalVal="";
		int length=word.length();
		if(word.length()>9)
		{
			System.out.println("invalid Number Entered");
		}
		else if(number%100==0)
		{
			finalVal=ones[(int) (number/100)];
		}
		else if(number%100 <20 && number%100 >0)
		{
			finalVal=ones[(int) (number%100)];
		}
		
		else if(word.length()>=3)
		{
			String hundred=word.substring(length-3, length);
			String thousand=word.substring(0, length-3);
			finalVal=getThousandString(thousand)+getHundredString(hundred);	
		}
		
		return finalVal;
	}
	
	public static String getMillionString(String number)
	{
		return getHundredString(number)+"Million";
	}
	
	
	public static String getThousandString(String number)
	{
		String thousand="";
		String million="";		
		if(number.length()==0) {
			return"";
		}
		if(number.length()>3)
		{
			thousand=number.substring(number.length()-3, number.length());
			million=number.substring(0, number.length()-3);
		}
		else
		{
			return getHundredString(number)+" Thousand";
		}
		return getMillionString(million)+getHundredString(thousand)+"Thousand";
	}
	
	
	public static String getHundredString(String number)
	{
		String hundredString=" Hundred and ";
		long value=Long.parseLong(number);
		String wordsTillNow="";
		if(value%100==0)
		{
			wordsTillNow=ones[(int) (value/100)]+" Hundred";
		}
		else if(value%100 <20 && value%100 >0)
		{
			wordsTillNow=ones[(int) (value/100)]+hundredString+ones[(int) (value%100)];
		}
		else
		{
			
			if(value/100==0)
			{
				hundredString="";
			}
			long remainder=value%100;
			if(remainder <20)
			{
				wordsTillNow=ones[(int) (remainder)];
			}
			else
			{
				wordsTillNow=ones[(int) (value/100)]+hundredString+tens[(int) (remainder/10)]+ones[(int) (remainder%10)];
			}
			
		}
		
		return wordsTillNow;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Long number=1L;
		try {
			String words=numberConverter(number);
			System.out.println(words);
		}
		catch (Exception ex)
		{
			System.out.println(ex.toString());
		}
		

	}

}
